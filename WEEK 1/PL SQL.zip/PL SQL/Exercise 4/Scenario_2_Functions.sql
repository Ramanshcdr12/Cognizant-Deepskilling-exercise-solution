-- Exercise 4: Functions
-- Scenario 2: Compute the monthly installment for a loan.
-- Question: Write a function CalculateMonthlyInstallment that takes the loan amount, interest rate, 
-- and loan duration in years as input and returns the monthly installment amount.

CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment (
    p_loan_amount    IN NUMBER,
    p_interest_rate  IN NUMBER, -- Annual interest rate (e.g. 5 for 5%)
    p_duration_years IN NUMBER
) RETURN NUMBER IS
    v_monthly_rate NUMBER;
    v_num_months   NUMBER;
    v_installment  NUMBER;
BEGIN
    -- Validation: Check for invalid input
    IF p_loan_amount <= 0 OR p_duration_years <= 0 OR p_interest_rate < 0 THEN
        RETURN 0;
    END IF;

    -- If interest rate is 0, EMI is simply principal divided by number of months
    IF p_interest_rate = 0 THEN
        RETURN ROUND(p_loan_amount / (p_duration_years * 12), 2);
    END IF;

    -- Monthly interest rate (annual rate divided by 12 months and 100 for percentage)
    v_monthly_rate := p_interest_rate / (12 * 100);
    
    -- Number of monthly installments
    v_num_months := p_duration_years * 12;

    -- Formula: EMI = (P * r * (1 + r)^n) / ((1 + r)^n - 1)
    v_installment := (p_loan_amount * v_monthly_rate * POWER(1 + v_monthly_rate, v_num_months)) / 
                     (POWER(1 + v_monthly_rate, v_num_months) - 1);

    RETURN ROUND(v_installment, 2);
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END CalculateMonthlyInstallment;
/

-- Verification Script
/*
-- 1. Test Case A: Calculate EMI for a $10,000 loan at 6% interest for 5 years
SELECT CalculateMonthlyInstallment(10000, 6, 5) AS MonthlyInstallment FROM DUAL; -- Expected: ~193.33

-- 2. Test Case B: Fetch from existing loans (e.g., Duration = EndDate - StartDate in years)
SELECT LoanID, LoanAmount, InterestRate, StartDate, EndDate,
       CalculateMonthlyInstallment(LoanAmount, InterestRate, ROUND((EndDate - StartDate) / 365, 1)) AS Monthly_EMI
FROM Loans;
*/
