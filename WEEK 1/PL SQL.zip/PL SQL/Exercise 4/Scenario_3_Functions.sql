-- Exercise 4: Functions
-- Scenario 3: Check if a customer has sufficient balance before making a transaction.
-- Question: Write a function HasSufficientBalance that takes an account ID and an amount as input 
-- and returns a boolean indicating whether the account has at least the specified amount.

CREATE OR REPLACE FUNCTION HasSufficientBalance (
    p_account_id IN NUMBER,
    p_amount     IN NUMBER
) RETURN BOOLEAN IS
    v_balance NUMBER;
BEGIN
    -- Validation: Amount to check must be non-negative
    IF p_amount < 0 THEN
        RETURN FALSE;
    END IF;

    -- Fetch the account balance
    SELECT Balance INTO v_balance
    FROM Accounts
    WHERE AccountID = p_account_id;

    -- Return true if balance is sufficient, false otherwise
    IF v_balance >= p_amount THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        -- Account does not exist, so balance is insufficient
        RETURN FALSE;
    WHEN OTHERS THEN
        RETURN FALSE;
END HasSufficientBalance;
/

-- Verification Script
-- Note: Oracle SQL does not support Boolean types natively in SELECT statements. 
-- This function must be executed within a PL/SQL block.
/*
DECLARE
    v_has_funds BOOLEAN;
BEGIN
    -- Test Case A: Customer has sufficient balance
    v_has_funds := HasSufficientBalance(1, 500); -- Account 1 has $1000 (after sample inserts)
    IF v_has_funds THEN
        DBMS_OUTPUT.PUT_LINE('Test Case A: Account 1 has sufficient funds for $500.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Test Case A: Account 1 does NOT have sufficient funds.');
    END IF;

    -- Test Case B: Customer does NOT have sufficient balance
    v_has_funds := HasSufficientBalance(1, 5000);
    IF v_has_funds THEN
        DBMS_OUTPUT.PUT_LINE('Test Case B: Account 1 has sufficient funds for $5000.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Test Case B: Account 1 does NOT have sufficient funds.');
    END IF;
END;
/
*/
