-- Exercise 4: Functions
-- Scenario 1: Calculate the age of customers for eligibility checks.
-- Question: Write a function CalculateAge that takes a customer's date of birth as input and returns their age in years.

CREATE OR REPLACE FUNCTION CalculateAge (
    p_dob IN DATE
) RETURN NUMBER IS
BEGIN
    IF p_dob IS NULL THEN
        RETURN NULL;
    END IF;
    
    -- Calculate age in years
    RETURN TRUNC(MONTHS_BETWEEN(SYSDATE, p_dob) / 12);
END CalculateAge;
/

-- Verification Script
/*
-- 1. Test Case A: Query existing customers' age:
SELECT CustomerID, Name, DOB, CalculateAge(DOB) AS CalculatedAge FROM Customers;

-- 2. Test Case B: Test in anonymous block:
DECLARE
    v_age NUMBER;
BEGIN
    v_age := CalculateAge(TO_DATE('1990-01-01', 'YYYY-MM-DD'));
    DBMS_OUTPUT.PUT_LINE('Age: ' || v_age); -- Should be current year - 1990
END;
/
*/
