-- Exercise 5: Triggers
-- Scenario 2: Maintain an audit log for all transactions.
-- Question: Write a trigger LogTransaction that inserts a record into an AuditLog table 
-- whenever a transaction is inserted into the Transactions table.

CREATE OR REPLACE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
    -- Insert audit log entry
    INSERT INTO AuditLog (
        TransactionID, 
        AccountID, 
        TransactionDate, 
        Amount, 
        TransactionType, 
        LogDate
    ) VALUES (
        :new.TransactionID,
        :new.AccountID,
        :new.TransactionDate,
        :new.Amount,
        :new.TransactionType,
        SYSDATE
    );
END;
/

-- Verification Script
/*
-- 1. Ensure the AuditLog table is currently empty:
SELECT * FROM AuditLog;

-- 2. Insert a new transaction into the Transactions table:
-- (Ensure AccountID 1 exists before running this)
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (99, 1, SYSDATE, 500, 'Deposit');

-- 3. Verify that the transaction was automatically audited:
SELECT * FROM AuditLog;
*/
