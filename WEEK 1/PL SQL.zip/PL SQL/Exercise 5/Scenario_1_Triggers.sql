-- Exercise 5: Triggers
-- Scenario 1: Automatically update the last modified date when a customer's record is updated.
-- Question: Write a trigger UpdateCustomerLastModified that updates the LastModified column 
-- of the Customers table to the current date whenever a customer's record is updated.

CREATE OR REPLACE TRIGGER UpdateCustomerLastModified
BEFORE UPDATE ON Customers
FOR EACH ROW
BEGIN
    -- Set LastModified to the current system date and time
    :new.LastModified := SYSDATE;
END;
/

-- Verification Script
/*
-- 1. Check initial LastModified value for John Doe (ID: 1):
SELECT CustomerID, Name, LastModified FROM Customers WHERE CustomerID = 1;

-- 2. Update John Doe's record:
UPDATE Customers
SET Balance = Balance + 50
WHERE CustomerID = 1;

-- 3. Verify that LastModified was updated automatically:
SELECT CustomerID, Name, LastModified FROM Customers WHERE CustomerID = 1;
*/
