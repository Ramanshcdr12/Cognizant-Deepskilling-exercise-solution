-- Exercise 5: Triggers
-- Scenario 3: Enforce business rules on deposits and withdrawals.
-- Question: Write a trigger CheckTransactionRules that ensures withdrawals do not exceed the balance 
-- and deposits are positive before inserting a record into the Transactions table.

CREATE OR REPLACE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
DECLARE
    v_balance NUMBER;
BEGIN
    -- 1. Ensure transaction amount is strictly positive
    IF :new.Amount <= 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Transaction amount must be positive. Provided: ' || :new.Amount);
    END IF;

    -- 2. Enforce rules based on TransactionType
    IF :new.TransactionType = 'Withdrawal' THEN
        -- Fetch account balance
        SELECT Balance INTO v_balance
        FROM Accounts
        WHERE AccountID = :new.AccountID;

        -- Check if withdrawal amount exceeds the balance
        IF v_balance < :new.Amount THEN
            RAISE_APPLICATION_ERROR(-20002, 'Insufficient funds. Account balance is $' || v_balance || 
                                    ', which is less than requested withdrawal of $' || :new.Amount);
        END IF;
    ELSIF :new.TransactionType = 'Deposit' then
        -- Deposits are already verified positive above
        NULL;
    ELSE
        RAISE_APPLICATION_ERROR(-20003, 'Invalid transaction type: ' || :new.TransactionType || 
                                '. Must be either Deposit or Withdrawal.');
    END IF;
END;
/

-- Verification Script
/*
-- 1. Check current balance of Account 1 (should be $1000 after sample insert):
SELECT AccountID, Balance FROM Accounts WHERE AccountID = 1;

-- 2. Test Case A: Attempt a negative deposit (throws error)
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (101, 1, SYSDATE, -50, 'Deposit');

-- 3. Test Case B: Attempt withdrawal exceeding balance (throws error)
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (102, 1, SYSDATE, 5000, 'Withdrawal');

-- 4. Test Case C: Successful withdrawal
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (103, 1, SYSDATE, 200, 'Withdrawal');
-- Note: You would also need to update the account balance manually or via a separate process
-- because this trigger only *checks* rules, it doesn't automatically perform the account update.
*/
