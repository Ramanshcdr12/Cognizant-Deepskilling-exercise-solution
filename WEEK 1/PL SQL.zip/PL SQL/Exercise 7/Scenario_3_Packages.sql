-- Exercise 7: Packages
-- Scenario 3: Group all account-related operations into a package.
-- Question: Create a package AccountOperations with procedures for opening a new account, 
-- closing an account, and a function to get the total balance of a customer across all accounts.

CREATE OR REPLACE PACKAGE AccountOperations AS
    -- Procedure to open a new account
    PROCEDURE OpenAccount(
        p_account_id   IN NUMBER,
        p_customer_id  IN NUMBER,
        p_account_type IN VARCHAR2,
        p_balance      IN NUMBER
    );

    -- Procedure to close an account
    PROCEDURE CloseAccount(
        p_account_id   IN NUMBER
    );

    -- Function to calculate total balance of a customer across all accounts
    FUNCTION GetTotalBalance(
        p_customer_id  IN NUMBER
    ) RETURN NUMBER;
END AccountOperations;
/

CREATE OR REPLACE PACKAGE BODY AccountOperations AS

    PROCEDURE OpenAccount(
        p_account_id   IN NUMBER,
        p_customer_id  IN NUMBER,
        p_account_type IN VARCHAR2,
        p_balance      IN NUMBER
    ) IS
        customer_not_found EXCEPTION;
        v_cust_exists NUMBER;
    BEGIN
        -- Check if customer exists first (referential integrity)
        BEGIN
            SELECT 1 INTO v_cust_exists FROM Customers WHERE CustomerID = p_customer_id;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RAISE customer_not_found;
        END;

        INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
        VALUES (p_account_id, p_customer_id, p_account_type, p_balance, SYSDATE);
        
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('AccountOperations Package: Opened Account ID ' || p_account_id || 
                             ' for Customer ID ' || p_customer_id);
    EXCEPTION
        WHEN customer_not_found THEN
            DBMS_OUTPUT.PUT_LINE('ERROR (Package OpenAccount): Cannot open account. Customer ID ' || p_customer_id || ' does not exist.');
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('ERROR (Package OpenAccount): Account ID ' || p_account_id || ' already exists.');
        WHEN OTHERS THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('ERROR (Package OpenAccount): ' || SQLERRM);
    END OpenAccount;

    PROCEDURE CloseAccount(
        p_account_id IN NUMBER
    ) IS
        account_not_found EXCEPTION;
    BEGIN
        DELETE FROM Accounts
        WHERE AccountID = p_account_id;

        IF SQL%ROWCOUNT = 0 THEN
            RAISE account_not_found;
        END IF;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('AccountOperations Package: Successfully closed Account ID ' || p_account_id);
    EXCEPTION
        WHEN account_not_found THEN
            DBMS_OUTPUT.PUT_LINE('ERROR (Package CloseAccount): Account ID ' || p_account_id || ' not found.');
        WHEN OTHERS THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('ERROR (Package CloseAccount): ' || SQLERRM);
    END CloseAccount;

    FUNCTION GetTotalBalance(
        p_customer_id IN NUMBER
    ) RETURN NUMBER IS
        v_total_balance NUMBER;
        v_cust_exists NUMBER;
    BEGIN
        -- Validate customer existence
        SELECT 1 INTO v_cust_exists FROM Customers WHERE CustomerID = p_customer_id;

        SELECT SUM(Balance) INTO v_total_balance
        FROM Accounts
        WHERE CustomerID = p_customer_id;

        -- If customer exists but has no accounts, SUM(Balance) is NULL, we return 0
        RETURN COALESCE(v_total_balance, 0);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('ERROR (Package GetTotalBalance): Customer ID ' || p_customer_id || ' not found.');
            RETURN NULL;
        WHEN OTHERS THEN
            RETURN NULL;
    END GetTotalBalance;

END AccountOperations;
/

-- Verification Script
/*
-- 1. Test Package OpenAccount:
-- Open a second account for customer 1
BEGIN
    AccountOperations.OpenAccount(10, 1, 'Checking', 2500);
END;
/
SELECT * FROM Accounts WHERE CustomerID = 1;

-- 2. Test Package GetTotalBalance:
-- Customer 1 now has Savings ($1000) and Checking ($2500)
SELECT AccountOperations.GetTotalBalance(1) AS TotalCustomerBalance FROM DUAL; -- Expected: 3500

-- 3. Test Package CloseAccount:
BEGIN
    AccountOperations.CloseAccount(10);
END;
/
SELECT * FROM Accounts WHERE CustomerID = 1;
*/
