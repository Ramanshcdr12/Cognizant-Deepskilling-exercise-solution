-- Exercise 7: Packages
-- Scenario 2: Create a package to manage employee data.
-- Question: Write a package EmployeeManagement with procedures to hire new employees, 
-- update employee details, and a function to calculate annual salary.

CREATE OR REPLACE PACKAGE EmployeeManagement AS
    -- Procedure to hire a new employee
    PROCEDURE HireNewEmployee(
        p_employee_id IN NUMBER,
        p_name        IN VARCHAR2,
        p_position    IN VARCHAR2,
        p_salary      IN NUMBER,
        p_department  IN VARCHAR2,
        p_hire_date   IN DATE
    );

    -- Procedure to update employee details
    PROCEDURE UpdateEmployeeDetails(
        p_employee_id IN NUMBER,
        p_name        IN VARCHAR2,
        p_position    IN VARCHAR2,
        p_salary      IN NUMBER,
        p_department  IN VARCHAR2
    );

    -- Function to calculate annual salary (monthly salary * 12)
    FUNCTION CalculateAnnualSalary(
        p_employee_id IN NUMBER
    ) RETURN NUMBER;
END EmployeeManagement;
/

CREATE OR REPLACE PACKAGE BODY EmployeeManagement AS

    PROCEDURE HireNewEmployee(
        p_employee_id IN NUMBER,
        p_name        IN VARCHAR2,
        p_position    IN VARCHAR2,
        p_salary      IN NUMBER,
        p_department  IN VARCHAR2,
        p_hire_date   IN DATE
    ) IS
    BEGIN
        INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
        VALUES (p_employee_id, p_name, p_position, p_salary, p_department, p_hire_date);
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('EmployeeManagement Package: Hired Employee ' || p_name || ' (ID: ' || p_employee_id || ')');
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('ERROR (Package HireNewEmployee): Employee ID ' || p_employee_id || ' already exists.');
        WHEN OTHERS THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('ERROR (Package HireNewEmployee): ' || SQLERRM);
    END HireNewEmployee;

    PROCEDURE UpdateEmployeeDetails(
        p_employee_id IN NUMBER,
        p_name        IN VARCHAR2,
        p_position    IN VARCHAR2,
        p_salary      IN NUMBER,
        p_department  IN VARCHAR2
    ) IS
        emp_not_found EXCEPTION;
    BEGIN
        UPDATE Employees
        SET Name = p_name,
            Position = p_position,
            Salary = p_salary,
            Department = p_department
        WHERE EmployeeID = p_employee_id;

        IF SQL%ROWCOUNT = 0 THEN
            RAISE emp_not_found;
        END IF;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('EmployeeManagement Package: Updated details for Employee ID ' || p_employee_id);
    EXCEPTION
        WHEN emp_not_found THEN
            DBMS_OUTPUT.PUT_LINE('ERROR (Package UpdateEmployeeDetails): Employee ID ' || p_employee_id || ' not found.');
        WHEN OTHERS THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('ERROR (Package UpdateEmployeeDetails): ' || SQLERRM);
    END UpdateEmployeeDetails;

    FUNCTION CalculateAnnualSalary(
        p_employee_id IN NUMBER
    ) RETURN NUMBER IS
        v_salary NUMBER;
    BEGIN
        SELECT Salary INTO v_salary
        FROM Employees
        WHERE EmployeeID = p_employee_id;

        RETURN v_salary * 12;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('ERROR (Package CalculateAnnualSalary): Employee ID ' || p_employee_id || ' not found.');
            RETURN NULL;
        WHEN OTHERS THEN
            RETURN NULL;
    END CalculateAnnualSalary;

END EmployeeManagement;
/

-- Verification Script
/*
-- 1. Test Package HireNewEmployee:
BEGIN
    EmployeeManagement.HireNewEmployee(101, 'Walter White', 'Chemist', 95000, 'R&D', TO_DATE('2008-01-20', 'YYYY-MM-DD'));
END;
/
SELECT * FROM Employees WHERE EmployeeID = 101;

-- 2. Test Package UpdateEmployeeDetails:
BEGIN
    EmployeeManagement.UpdateEmployeeDetails(101, 'Walter Hartwell White', 'Lead Chemist', 120000, 'R&D');
END;
/
SELECT * FROM Employees WHERE EmployeeID = 101;

-- 3. Test Package CalculateAnnualSalary function:
SELECT EmployeeManagement.CalculateAnnualSalary(101) AS AnnualSalary FROM DUAL; -- Expected: 1440000 (120000 * 12)
*/
