-- Exercise 7: Packages
-- Scenario 1: Group all customer-related procedures and functions into a package.
-- Question: Create a package CustomerManagement with procedures for adding a new customer, 
-- updating customer details, and a function to get customer balance.

CREATE OR REPLACE PACKAGE CustomerManagement AS
    -- Procedure to add a new customer
    PROCEDURE AddNewCustomer(
        p_customer_id IN NUMBER,
        p_name        IN VARCHAR2,
        p_dob         IN DATE,
        p_balance     IN NUMBER
    );
    
    -- Procedure to update customer details (name and DOB)
    PROCEDURE UpdateCustomerDetails(
        p_customer_id IN NUMBER,
        p_name        IN VARCHAR2,
        p_dob         IN DATE
    );
    
    -- Function to get a customer's balance
    FUNCTION GetCustomerBalance(
        p_customer_id IN NUMBER
    ) RETURN NUMBER;
END CustomerManagement;
/

CREATE OR REPLACE PACKAGE BODY CustomerManagement AS

    PROCEDURE AddNewCustomer(
        p_customer_id IN NUMBER,
        p_name        IN VARCHAR2,
        p_dob         IN DATE,
        p_balance     IN NUMBER
    ) IS
    BEGIN
        INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified, IsVIP)
        VALUES (p_customer_id, p_name, p_dob, p_balance, SYSDATE, 'FALSE');
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('CustomerManagement Package: Successfully added Customer ' || p_name || ' (ID: ' || p_customer_id || ')');
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('ERROR (Package AddNewCustomer): Customer ID ' || p_customer_id || ' already exists.');
        WHEN OTHERS THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('ERROR (Package AddNewCustomer): ' || SQLERRM);
    END AddNewCustomer;

    PROCEDURE UpdateCustomerDetails(
        p_customer_id IN NUMBER,
        p_name        IN VARCHAR2,
        p_dob         IN DATE
    ) IS
        customer_not_found EXCEPTION;
    BEGIN
        UPDATE Customers
        SET Name = p_name,
            DOB = p_dob,
            LastModified = SYSDATE
        WHERE CustomerID = p_customer_id;
        
        IF SQL%ROWCOUNT = 0 THEN
            RAISE customer_not_found;
        END IF;
        
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('CustomerManagement Package: Successfully updated details for Customer ID ' || p_customer_id);
    EXCEPTION
        WHEN customer_not_found THEN
            DBMS_OUTPUT.PUT_LINE('ERROR (Package UpdateCustomerDetails): Customer ID ' || p_customer_id || ' not found.');
        WHEN OTHERS THEN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('ERROR (Package UpdateCustomerDetails): ' || SQLERRM);
    END UpdateCustomerDetails;

    FUNCTION GetCustomerBalance(
        p_customer_id IN NUMBER
    ) RETURN NUMBER IS
        v_balance NUMBER;
    BEGIN
        SELECT Balance INTO v_balance
        FROM Customers
        WHERE CustomerID = p_customer_id;
        
        RETURN v_balance;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('ERROR (Package GetCustomerBalance): Customer ID ' || p_customer_id || ' not found.');
            RETURN NULL;
        WHEN OTHERS THEN
            RETURN NULL;
    END GetCustomerBalance;

END CustomerManagement;
/

-- Verification Script
/*
-- 1. Test Package AddNewCustomer:
BEGIN
    CustomerManagement.AddNewCustomer(10, 'Gordon Ramsay', TO_DATE('1966-11-08', 'YYYY-MM-DD'), 30000);
END;
/
SELECT * FROM Customers WHERE CustomerID = 10;

-- 2. Test Package UpdateCustomerDetails:
BEGIN
    CustomerManagement.UpdateCustomerDetails(10, 'Gordon James Ramsay', TO_DATE('1966-11-08', 'YYYY-MM-DD'));
END;
/
SELECT * FROM Customers WHERE CustomerID = 10;

-- 3. Test Package GetCustomerBalance function:
SELECT CustomerManagement.GetCustomerBalance(10) AS CustomerBalance FROM DUAL;
*/
