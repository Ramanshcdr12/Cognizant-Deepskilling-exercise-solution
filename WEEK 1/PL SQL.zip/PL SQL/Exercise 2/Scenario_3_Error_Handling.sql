-- Exercise 2: Error Handling
-- Scenario 3: Ensure data integrity when adding a new customer.
-- Question: Write a stored procedure AddNewCustomer that inserts a new customer into the Customers table. 
-- If a customer with the same ID already exists, handle the exception by logging an error and preventing the insertion.

CREATE OR REPLACE PROCEDURE AddNewCustomer (
    p_customer_id IN NUMBER,
    p_name        IN VARCHAR2,
    p_dob         IN DATE,
    p_balance     IN NUMBER
) IS
BEGIN
    -- Attempt to insert the new customer record
    INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified, IsVIP)
    VALUES (p_customer_id, p_name, p_dob, p_balance, SYSDATE, 'FALSE');

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Successfully added new customer: ' || p_name || ' (ID: ' || p_customer_id || ')');

EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: Failed to add customer. A customer with ID ' || p_customer_id || ' already exists.');
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: An unexpected error occurred during insertion: ' || SQLERRM);
END AddNewCustomer;
/

-- Verification Script
/*
-- 1. Check existing customer table:
SELECT * FROM Customers;

-- 2. Test Case A: Insert a unique customer
BEGIN
    AddNewCustomer(5, 'David Beckham', TO_DATE('1975-05-02', 'YYYY-MM-DD'), 25000);
END;
/
SELECT * FROM Customers;

-- 3. Test Case B: Insert a duplicate customer ID (trying ID 1 again)
BEGIN
    AddNewCustomer(1, 'Duplicate John', TO_DATE('1990-01-01', 'YYYY-MM-DD'), 100);
END;
/
*/
