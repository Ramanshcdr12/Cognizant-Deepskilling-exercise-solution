-- Exercise 2: Error Handling
-- Scenario 1: Handle exceptions during fund transfers between accounts.
-- Question: Write a stored procedure SafeTransferFunds that transfers funds between two accounts. 
-- Ensure that if any error occurs (e.g., insufficient funds), an appropriate error message is logged and the transaction is rolled back.

CREATE OR REPLACE PROCEDURE SafeTransferFunds (
    p_from_account IN NUMBER,
    p_to_account   IN NUMBER,
    p_amount       IN NUMBER
) IS
    v_from_balance NUMBER;
    v_to_balance   NUMBER;
    
    -- Custom Exceptions
    insufficient_funds EXCEPTION;
    same_account EXCEPTION;
    invalid_amount EXCEPTION;
BEGIN
    -- Basic validation: Amount must be positive
    IF p_amount <= 0 THEN
        RAISE invalid_amount;
    END IF;
    
    -- Basic validation: Cannot transfer to the same account
    IF p_from_account = p_to_account THEN
        RAISE same_account;
    END IF;

    -- Check source account existence and balance
    BEGIN
        SELECT Balance INTO v_from_balance
        FROM Accounts
        WHERE AccountID = p_from_account
        FOR UPDATE; -- Lock row for integrity
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20001, 'Source account ' || p_from_account || ' does not exist.');
    END;

    -- Check destination account existence
    BEGIN
        SELECT Balance INTO v_to_balance
        FROM Accounts
        WHERE AccountID = p_to_account
        FOR UPDATE; -- Lock row for integrity
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20002, 'Destination account ' || p_to_account || ' does not exist.');
    END;

    -- Check for sufficient funds
    IF v_from_balance < p_amount THEN
        RAISE insufficient_funds;
    END IF;

    -- Perform the transfer: Debit source account
    UPDATE Accounts
    SET Balance = Balance - p_amount,
        LastModified = SYSDATE
    WHERE AccountID = p_from_account;

    -- Perform the transfer: Credit destination account
    UPDATE Accounts
    SET Balance = Balance + p_amount,
        LastModified = SYSDATE
    WHERE AccountID = p_to_account;

    -- Log transactions
    -- Since TransactionID is primary key, we fetch the max ID + 1 or let it fail if not managed (we will insert with generated sequences or next ID)
    INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
    VALUES (
        (SELECT COALESCE(MAX(TransactionID), 0) + 1 FROM Transactions), 
        p_from_account, 
        SYSDATE, 
        p_amount, 
        'Withdrawal'
    );

    INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
    VALUES (
        (SELECT COALESCE(MAX(TransactionID), 0) + 1 FROM Transactions), 
        p_to_account, 
        SYSDATE, 
        p_amount, 
        'Deposit'
    );

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Successfully transferred $' || p_amount || ' from Account ' || p_from_account || ' to Account ' || p_to_account);

EXCEPTION
    WHEN insufficient_funds THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: Transfer failed due to insufficient funds in Account ' || p_from_account);
    WHEN same_account THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: Source and destination accounts cannot be the same.');
    WHEN invalid_amount THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: Transfer amount must be positive.');
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: Transfer failed. Oracle Error Code: ' || SQLCODE || ' - ' || SQLERRM);
END SafeTransferFunds;
/

-- Verification Script
/*
-- 1. Check current account balances:
SELECT AccountID, Balance FROM Accounts;

-- 2. Test Case A: Successful transfer
BEGIN
    SafeTransferFunds(1, 2, 200);
END;
/
SELECT AccountID, Balance FROM Accounts;

-- 3. Test Case B: Insufficient funds (transfer 5000 from account 1 which has < 1000)
BEGIN
    SafeTransferFunds(1, 2, 5000);
END;
/
SELECT AccountID, Balance FROM Accounts;

-- 4. Test Case C: Non-existent account
BEGIN
    SafeTransferFunds(99, 2, 100);
END;
/
*/
