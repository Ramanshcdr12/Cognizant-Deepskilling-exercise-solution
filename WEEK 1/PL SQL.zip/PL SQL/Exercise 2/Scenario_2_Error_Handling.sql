-- Exercise 2: Error Handling
-- Scenario 2: Manage errors when updating employee salaries.
-- Question: Write a stored procedure UpdateSalary that increases the salary of an employee by a given percentage. 
-- If the employee ID does not exist, handle the exception and log an error message.

CREATE OR REPLACE PROCEDURE UpdateSalary (
    p_emp_id     IN NUMBER,
    p_percentage IN NUMBER
) IS
    emp_not_found EXCEPTION;
BEGIN
    -- Update the salary
    UPDATE Employees
    SET Salary = Salary * (1 + p_percentage / 100)
    WHERE EmployeeID = p_emp_id;

    -- If no row was updated, it means the employee ID does not exist
    IF SQL%ROWCOUNT = 0 THEN
        RAISE emp_not_found;
    END IF;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Successfully increased salary for Employee ID: ' || p_emp_id || ' by ' || p_percentage || '%');

EXCEPTION
    WHEN emp_not_found THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Update failed. Employee with ID ' || p_emp_id || ' does not exist.');
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: An unexpected error occurred: ' || SQLERRM);
END UpdateSalary;
/

-- Verification Script
/*
-- 1. Check existing employee salaries:
SELECT EmployeeID, Name, Salary FROM Employees;

-- 2. Test Case A: Existing Employee (Update employee 1 by 10%)
BEGIN
    UpdateSalary(1, 10);
END;
/
SELECT EmployeeID, Name, Salary FROM Employees;

-- 3. Test Case B: Non-existent Employee (ID: 999)
BEGIN
    UpdateSalary(999, 10);
END;
/
*/
