-- Exercise 1: Control Structures
-- Scenario 2: Promote a customer to VIP status based on their balance.
-- Question: Write a PL/SQL block that iterates through all customers and sets a flag IsVIP to TRUE for those with a balance over $10,000.

SET SERVEROUTPUT ON;

BEGIN
    FOR r_cust IN (
        SELECT CustomerID, Name, Balance 
        FROM Customers
    ) LOOP
        IF r_cust.Balance > 10000 THEN
            UPDATE Customers
            SET IsVIP = 'TRUE'
            WHERE CustomerID = r_cust.CustomerID;
            
            DBMS_OUTPUT.PUT_LINE('Promoted Customer ' || r_cust.Name || ' (ID: ' || r_cust.CustomerID || ') to VIP. Balance: $' || r_cust.Balance);
        END IF;
    END LOOP;
    
    COMMIT;
END;
/

-- Verification Script
/*
-- 1. Check initial VIP status and balance of customers:
SELECT CustomerID, Name, Balance, IsVIP FROM Customers;

-- 2. Execute the PL/SQL block above.

-- 3. Check VIP status and balance of customers after update:
SELECT CustomerID, Name, Balance, IsVIP FROM Customers;
*/
