-- Exercise 1: Control Structures
-- Scenario 1: Apply a discount to loan interest rates for customers above 60 years old.
-- Question: Write a PL/SQL block that loops through all customers, checks their age, and if they are above 60, apply a 1% discount to their current loan interest rates.

SET SERVEROUTPUT ON;

DECLARE
    v_age NUMBER;
BEGIN
    FOR r_cust IN (
        SELECT CustomerID, Name, DOB 
        FROM Customers
    ) LOOP
        -- Calculate age based on Date of Birth
        IF r_cust.DOB IS NOT NULL THEN
            v_age := MONTHS_BETWEEN(SYSDATE, r_cust.DOB) / 12;
            
            IF v_age > 60 THEN
                -- Apply a 1% discount (deduct 1 from interest rate)
                UPDATE Loans
                SET InterestRate = InterestRate - 1
                WHERE CustomerID = r_cust.CustomerID;
                
                DBMS_OUTPUT.PUT_LINE('Applied 1% interest rate discount to Customer: ' || r_cust.Name || ' (Age: ' || ROUND(v_age, 1) || ')');
            END IF;
        END IF;
    END LOOP;
    
    COMMIT;
END;
/

-- Verification Script
/*
-- 1. Check initial loan interest rates:
SELECT c.Name, c.DOB, l.LoanID, l.InterestRate 
FROM Customers c
JOIN Loans l ON c.CustomerID = l.CustomerID;

-- 2. Execute the PL/SQL block above.

-- 3. Check loan interest rates after the discount:
SELECT c.Name, c.DOB, l.LoanID, l.InterestRate 
FROM Customers c
JOIN Loans l ON c.CustomerID = l.CustomerID;
*/
