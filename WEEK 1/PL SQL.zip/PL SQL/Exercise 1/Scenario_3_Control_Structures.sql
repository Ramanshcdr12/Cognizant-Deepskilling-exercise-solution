-- Exercise 1: Control Structures
-- Scenario 3: Send reminders to customers whose loans are due within the next 30 days.
-- Question: Write a PL/SQL block that fetches all loans due in the next 30 days and prints a reminder message for each customer.

SET SERVEROUTPUT ON;

DECLARE
    CURSOR c_due_loans IS
        SELECT c.Name, l.LoanID, l.EndDate, l.LoanAmount
        FROM Customers c
        JOIN Loans l ON c.CustomerID = l.CustomerID
        WHERE l.EndDate BETWEEN SYSDATE AND SYSDATE + 30;
    
    v_name Customers.Name%TYPE;
    v_loan_id Loans.LoanID%TYPE;
    v_end_date Loans.EndDate%TYPE;
    v_amount Loans.LoanAmount%TYPE;
BEGIN
    OPEN c_due_loans;
    LOOP
        FETCH c_due_loans INTO v_name, v_loan_id, v_end_date, v_amount;
        EXIT WHEN c_due_loans%NOTFOUND;
        
        DBMS_OUTPUT.PUT_LINE('REMINDER: Dear ' || v_name || ', your loan (ID: ' || v_loan_id || 
                             ') of amount $' || v_amount || ' is due on ' || TO_CHAR(v_end_date, 'YYYY-MM-DD') || 
                             '. Please ensure timely payment.');
    END LOOP;
    CLOSE c_due_loans;
END;
/

-- Verification Script
/*
-- 1. Check existing loans and their end dates:
SELECT c.Name, l.LoanID, l.EndDate, l.LoanAmount 
FROM Customers c
JOIN Loans l ON c.CustomerID = l.CustomerID;

-- 2. Execute the PL/SQL block above. (Customer Jane Smith's loan is set to end in 20 days in sample_data.sql)
*/
