-- Exercise 3: Stored Procedures
-- Scenario 3: Customers should be able to transfer funds between their accounts.
-- Question: Write a stored procedure TransferFunds that transfers a specified amount from one account 
-- to another, checking that the source account has sufficient balance before making the transfer.

CREATE OR REPLACE PROCEDURE TransferFunds (
    p_from_account IN NUMBER,
    p_to_account   IN NUMBER,
    p_amount       IN NUMBER
) IS
    v_from_balance NUMBER;
    v_account_exists NUMBER;
BEGIN
    -- Validation: Amount must be positive
    IF p_amount <= 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Transfer amount must be positive.');
    END IF;

    -- Check if source account exists and fetch balance
    BEGIN
        SELECT Balance INTO v_from_balance
        FROM Accounts
        WHERE AccountID = p_from_account
        FOR UPDATE;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20002, 'Source account ' || p_from_account || ' does not exist.');
    END;

    -- Check if destination account exists
    BEGIN
        SELECT 1 INTO v_account_exists
        FROM Accounts
        WHERE AccountID = p_to_account;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20003, 'Destination account ' || p_to_account || ' does not exist.');
    END;

    -- Check for sufficient balance
    IF v_from_balance < p_amount THEN
        RAISE_APPLICATION_ERROR(-20004, 'Insufficient funds in source account ' || p_from_account || 
                                '. Available: $' || v_from_balance || ', Attempted: $' || p_amount);
    END IF;

    -- Debit source account
    UPDATE Accounts
    SET Balance = Balance - p_amount,
        LastModified = SYSDATE
    WHERE AccountID = p_from_account;

    -- Credit destination account
    UPDATE Accounts
    SET Balance = Balance + p_amount,
        LastModified = SYSDATE
    WHERE AccountID = p_to_account;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Successfully transferred $' || p_amount || ' from Account ' || p_from_account || ' to Account ' || p_to_account);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        -- Re-raise custom application errors, otherwise print general message
        IF SQLCODE BETWEEN -20999 AND -20000 THEN
            RAISE;
        ELSE
            RAISE_APPLICATION_ERROR(-20999, 'Unexpected error during transfer: ' || SQLERRM);
        END IF;
END TransferFunds;
/

-- Verification Script
/*
-- 1. Check balances:
SELECT AccountID, Balance FROM Accounts;

-- 2. Test Case A: Sufficient balance transfer
BEGIN
    TransferFunds(2, 1, 100);
END;
/
SELECT AccountID, Balance FROM Accounts;

-- 3. Test Case B: Insufficient balance transfer (throws error)
BEGIN
    TransferFunds(1, 2, 9000);
END;
/
*/
