-- Exercise 3: Stored Procedures
-- Scenario 1: Process monthly interest for all savings accounts.
-- Question: Write a stored procedure ProcessMonthlyInterest that calculates and updates the balance of 
-- all savings accounts by applying an interest rate of 1% to the current balance.

CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest IS
    v_updated_rows NUMBER;
BEGIN
    -- Apply 1% interest rate to all accounts with AccountType = 'Savings'
    UPDATE Accounts
    SET Balance = Balance * 1.01,
        LastModified = SYSDATE
    WHERE AccountType = 'Savings';

    v_updated_rows := SQL%ROWCOUNT;
    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE('Processed monthly interest. Total savings accounts updated: ' || v_updated_rows);
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: Failed to process monthly interest. ' || SQLERRM);
END ProcessMonthlyInterest;
/

-- Verification Script
/*
-- 1. Check savings account balances before:
SELECT AccountID, CustomerID, AccountType, Balance FROM Accounts WHERE AccountType = 'Savings';

-- 2. Execute the procedure:
BEGIN
    ProcessMonthlyInterest;
END;
/

-- 3. Check savings account balances after:
SELECT AccountID, CustomerID, AccountType, Balance FROM Accounts WHERE AccountType = 'Savings';
*/
