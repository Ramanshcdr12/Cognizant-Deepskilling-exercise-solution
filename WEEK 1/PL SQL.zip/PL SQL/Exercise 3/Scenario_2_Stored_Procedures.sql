-- Exercise 3: Stored Procedures
-- Scenario 2: Implement a bonus scheme for employees based on their performance.
-- Question: Write a stored procedure UpdateEmployeeBonus that updates the salary of employees 
-- in a given department by adding a bonus percentage passed as a parameter.

CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus (
    p_department       IN VARCHAR2,
    p_bonus_percentage IN NUMBER
) IS
    v_updated_count NUMBER;
    invalid_bonus EXCEPTION;
BEGIN
    -- Validation: Bonus percentage cannot be negative
    IF p_bonus_percentage < 0 THEN
        RAISE invalid_bonus;
    END IF;

    -- Update salary of employees in the specified department
    UPDATE Employees
    SET Salary = Salary * (1 + p_bonus_percentage / 100)
    WHERE Department = p_department;

    v_updated_count := SQL%ROWCOUNT;
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Bonus update completed. Updated ' || v_updated_count || ' employee(s) in ' || p_department || ' department.');

EXCEPTION
    WHEN invalid_bonus THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Bonus percentage must be non-negative.');
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: Failed to update employee bonus. ' || SQLERRM);
END UpdateEmployeeBonus;
/

-- Verification Script
/*
-- 1. Check employee salaries in the 'IT' department:
SELECT EmployeeID, Name, Salary, Department FROM Employees WHERE Department = 'IT';

-- 2. Execute the procedure (e.g., 5% bonus for IT department)
BEGIN
    UpdateEmployeeBonus('IT', 5);
END;
/

-- 3. Check employee salaries in 'IT' department after update:
SELECT EmployeeID, Name, Salary, Department FROM Employees WHERE Department = 'IT';
*/
