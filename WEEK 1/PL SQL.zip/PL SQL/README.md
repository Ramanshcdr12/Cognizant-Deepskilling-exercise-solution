# PL/SQL DeepSkilling Exercises

This repository contains solutions for the PL/SQL exercises including Control Structures, Error Handling, Stored Procedures, Functions, Triggers, Cursors, and Packages.

## Database Schema Diagram

```
+------------------+         +------------------+         +------------------+
|    Customers     |         |     Accounts     |         |   Transactions   |
+------------------+         +------------------+         +------------------+
| CustomerID (PK)  | <-----+ | AccountID (PK)   | <-----+ | TransactionID(PK)|
| Name             |         | CustomerID (FK)  |         | AccountID (FK)   |
| DOB              |         | AccountType      |         | TransactionDate  |
| Balance          |         | Balance          |         | Amount           |
| LastModified     |         | LastModified     |         | TransactionType  |
| IsVIP            |         +------------------+         +------------------+
+------------------+
       ^
       |                     +------------------+
       +-------------------+ |      Loans       |
                             +------------------+
                             | LoanID (PK)      |
                             | CustomerID (FK)  |
                             | LoanAmount       |
                             | InterestRate     |
                             | StartDate        |
                             | EndDate          |
                             +------------------+

+------------------+         +------------------+
|    Employees     |         |     AuditLog     |
+------------------+         +------------------+
| EmployeeID (PK)  |         | LogID (PK)       |
| Name             |         | TransactionID    |
| Position         |         | AccountID        |
| Salary           |         | TransactionDate  |
| Department       |         | Amount           |
| HireDate         |         | TransactionType  |
+------------------+         | LogDate          |
                             +------------------+
```

## Repository Structure

The project is structured as follows:

*   [`schema.sql`](./schema.sql): Creates the base tables and foreign key constraints.
*   [`sample_data.sql`](./sample_data.sql): Inserts test records to verify PL/SQL solutions.
*   **Exercise folders:**
    *   [`Exercise 1/`](./Exercise%201/): Control Structures.
    *   [`Exercise 2/`](./Exercise%202/): Error Handling.
    *   [`Exercise 3/`](./Exercise%203/): Stored Procedures.
    *   [`Exercise 4/`](./Exercise%204/): Functions.
    *   [`Exercise 5/`](./Exercise%205/): Triggers.
    *   [`Exercise 6/`](./Exercise%206/): Cursors.
    *   [`Exercise 7/`](./Exercise%207/): Packages.

## How to Run

1.  Connect to your Oracle Database / SQL Developer.
2.  Run `schema.sql` to construct the tables.
3.  Run `sample_data.sql` to populate the tables with mock data.
4.  Navigate to individual folders and execute the `.sql` files. Each solution file contains verification blocks at the bottom to test correctness.
