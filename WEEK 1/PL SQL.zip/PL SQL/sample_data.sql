-- Sample data insertion script for PL/SQL exercises

-- Clean existing data to avoid PK violations on re-runs
TRUNCATE TABLE AuditLog;
DELETE FROM Transactions;
DELETE FROM Accounts;
DELETE FROM Loans;
DELETE FROM Customers;
DELETE FROM Employees;

-- Customers
-- John Doe: Under 60, balance < 10000
INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified, IsVIP)
VALUES (1, 'John Doe', TO_DATE('1985-05-15', 'YYYY-MM-DD'), 1000, SYSDATE, 'FALSE');

-- Jane Smith: Under 60, balance < 10000
INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified, IsVIP)
VALUES (2, 'Jane Smith', TO_DATE('1990-07-20', 'YYYY-MM-DD'), 1500, SYSDATE, 'FALSE');

-- Robert Miller: Over 60 (born 1955), balance < 10000
INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified, IsVIP)
VALUES (3, 'Robert Miller', TO_DATE('1955-03-10', 'YYYY-MM-DD'), 5000, SYSDATE, 'FALSE');

-- Alice Cooper: Under 60, balance > 10000 (VIP candidate)
INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified, IsVIP)
VALUES (4, 'Alice Cooper', TO_DATE('1975-11-30', 'YYYY-MM-DD'), 12000, SYSDATE, 'FALSE');

-- accounts
-- Account 1: Savings for John Doe (1000)
INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (1, 1, 'Savings', 1000, SYSDATE);

-- Account 2: Checking for Jane Smith (1500)
INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (2, 2, 'Checking', 1500, SYSDATE);

-- Account 3: Savings for Robert Miller (5000)
INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (3, 3, 'Savings', 5000, SYSDATE);

-- Account 4: Checking for Alice Cooper (12000)
INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
VALUES (4, 4, 'Checking', 12000, SYSDATE);

-- Transactions
INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (1, 1, SYSDATE - 15, 200, 'Deposit');

INSERT INTO Transactions (TransactionID, AccountID, TransactionDate, Amount, TransactionType)
VALUES (2, 2, SYSDATE - 10, 300, 'Withdrawal');

-- Loans
-- Loan for Customer 1 (John Doe, under 60)
INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (1, 1, 5000, 5, SYSDATE - 100, SYSDATE + 500);

-- Loan for Customer 3 (Robert Miller, over 60, eligible for 1% rate discount)
INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (2, 3, 10000, 6, SYSDATE - 200, SYSDATE + 1000);

-- Loan for Customer 2 (Jane Smith, due in next 30 days)
INSERT INTO Loans (LoanID, CustomerID, LoanAmount, InterestRate, StartDate, EndDate)
VALUES (3, 2, 8000, 5.5, SYSDATE - 330, SYSDATE + 20);

-- Employees
INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
VALUES (1, 'Alice Johnson', 'Manager', 70000, 'HR', TO_DATE('2015-06-15', 'YYYY-MM-DD'));

INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
VALUES (2, 'Bob Brown', 'Developer', 60000, 'IT', TO_DATE('2017-03-20', 'YYYY-MM-DD'));

INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
VALUES (3, 'Charlie Green', 'Developer', 55000, 'IT', TO_DATE('2019-10-10', 'YYYY-MM-DD'));

COMMIT;
