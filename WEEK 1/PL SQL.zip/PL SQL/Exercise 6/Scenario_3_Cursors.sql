-- Exercise 6: Cursors
-- Scenario 3: Update the interest rate for all loans based on a new policy.
-- Question: Write a PL/SQL block using an explicit cursor UpdateLoanInterestRates that fetches 
-- all loans and updates their interest rates based on the new policy.

SET SERVEROUTPUT ON;

DECLARE
    -- Explicit cursor to select all loans
    CURSOR UpdateLoanInterestRates IS
        SELECT LoanID, LoanAmount, InterestRate 
        FROM Loans
        FOR UPDATE;
        
    v_new_rate NUMBER;
BEGIN
    -- Policy definition:
    -- 1. High value loans (> $8000) get a 0.5% interest rate reduction.
    -- 2. Other loans (<= $8000) get a 0.25% interest rate increase.
    
    DBMS_OUTPUT.PUT_LINE('=== APPLYING NEW LOAN INTEREST POLICY ===');
    
    FOR r_loan IN UpdateLoanInterestRates LOOP
        IF r_loan.LoanAmount > 8000 THEN
            v_new_rate := r_loan.InterestRate - 0.5;
        ELSE
            v_new_rate := r_loan.InterestRate + 0.25;
        END IF;
        
        -- Update interest rate using WHERE CURRENT OF
        UPDATE Loans
        SET InterestRate = v_new_rate
        WHERE CURRENT OF UpdateLoanInterestRates;
        
        DBMS_OUTPUT.PUT_LINE('Loan ID: ' || r_loan.LoanID || 
                             ' | Amount: $' || LPAD(r_loan.LoanAmount, 6) || 
                             ' | Old Rate: ' || TO_CHAR(r_loan.InterestRate, '90.99') || '%' || 
                             ' | New Rate: ' || TO_CHAR(v_new_rate, '90.99') || '%');
    END LOOP;
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Interest rate update completed successfully.');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: Failed to update loan interest rates. ' || SQLERRM);
END;
/

-- Verification Script
/*
-- 1. Check interest rates before running:
SELECT LoanID, LoanAmount, InterestRate FROM Loans;

-- 2. Execute the PL/SQL block above.

-- 3. Check interest rates after running:
SELECT LoanID, LoanAmount, InterestRate FROM Loans;
*/
