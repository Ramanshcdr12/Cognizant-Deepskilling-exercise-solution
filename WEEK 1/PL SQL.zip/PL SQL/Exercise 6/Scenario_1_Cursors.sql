-- Exercise 6: Cursors
-- Scenario 1: Generate monthly statements for all customers.
-- Question: Write a PL/SQL block using an explicit cursor GenerateMonthlyStatements that retrieves 
-- all transactions for the current month and prints a statement for each customer.

SET SERVEROUTPUT ON;

DECLARE
    -- Explicit Cursor to fetch transactions for the current month grouped by customer
    CURSOR GenerateMonthlyStatements IS
        SELECT c.CustomerID, 
               c.Name AS CustomerName, 
               t.TransactionID, 
               t.TransactionDate, 
               t.Amount, 
               t.TransactionType, 
               a.AccountID,
               a.AccountType
        FROM Customers c
        JOIN Accounts a ON c.CustomerID = a.CustomerID
        JOIN Transactions t ON a.AccountID = t.AccountID
        WHERE TRUNC(t.TransactionDate, 'MM') = TRUNC(SYSDATE, 'MM')
        ORDER BY c.CustomerID, t.TransactionDate;
        
    v_prev_customer_id Customers.CustomerID%TYPE := -9999;
BEGIN
    DBMS_OUTPUT.PUT_LINE('=== MONTHLY STATEMENTS FOR ' || TO_CHAR(SYSDATE, 'MONTH YYYY') || ' ===');
    
    FOR r_trans IN GenerateMonthlyStatements LOOP
        -- Print header for a new customer
        IF r_trans.CustomerID <> v_prev_customer_id THEN
            DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------');
            DBMS_OUTPUT.PUT_LINE('Customer: ' || r_trans.CustomerName || ' (ID: ' || r_trans.CustomerID || ')');
            DBMS_OUTPUT.PUT_LINE('--------------------------------------------------------------------------------');
            v_prev_customer_id := r_trans.CustomerID;
        END IF;
        
        -- Print transaction details
        DBMS_OUTPUT.PUT_LINE('   TX_ID: ' || LPAD(r_trans.TransactionID, 5) || 
                             ' | Date: ' || TO_CHAR(r_trans.TransactionDate, 'YYYY-MM-DD') || 
                             ' | Account: ' || r_trans.AccountID || ' (' || r_trans.AccountType || ')' || 
                             ' | Type: ' || RPAD(r_trans.TransactionType, 10) || 
                             ' | Amount: $' || TO_CHAR(r_trans.Amount, '9999.00'));
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('================================================================================');
END;
/

-- Verification Script
/*
-- 1. Ensure transactions exist in the current month:
SELECT * FROM Transactions WHERE TRUNC(TransactionDate, 'MM') = TRUNC(SYSDATE, 'MM');

-- 2. Execute the PL/SQL block above.
*/
