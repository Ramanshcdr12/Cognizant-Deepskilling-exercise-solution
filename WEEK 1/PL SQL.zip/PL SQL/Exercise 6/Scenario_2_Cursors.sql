-- Exercise 6: Cursors
-- Scenario 2: Apply annual fee to all accounts.
-- Question: Write a PL/SQL block using an explicit cursor ApplyAnnualFee that deducts an annual 
-- maintenance fee from the balance of all accounts.

SET SERVEROUTPUT ON;

DECLARE
    -- Flat annual maintenance fee
    c_annual_fee CONSTANT NUMBER := 50;
    
    -- Explicit cursor to select all accounts
    CURSOR ApplyAnnualFee IS
        SELECT AccountID, Balance 
        FROM Accounts
        FOR UPDATE; -- Lock rows for update
BEGIN
    FOR r_acc IN ApplyAnnualFee LOOP
        -- Deduct the fee from the account balance
        UPDATE Accounts
        SET Balance = Balance - c_annual_fee,
            LastModified = SYSDATE
        WHERE CURRENT OF ApplyAnnualFee; -- Updates the current row fetched by the cursor
        
        DBMS_OUTPUT.PUT_LINE('Account ID: ' || r_acc.AccountID || 
                             ' | Old Balance: $' || r_acc.Balance || 
                             ' | New Balance: $' || (r_acc.Balance - c_annual_fee));
    END LOOP;
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Annual maintenance fee applied to all accounts successfully.');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: Failed to apply annual fee. ' || SQLERRM);
END;
/

-- Verification Script
/*
-- 1. Check account balances before running:
SELECT AccountID, Balance FROM Accounts;

-- 2. Execute the PL/SQL block above.

-- 3. Check account balances after running:
SELECT AccountID, Balance FROM Accounts;
*/
