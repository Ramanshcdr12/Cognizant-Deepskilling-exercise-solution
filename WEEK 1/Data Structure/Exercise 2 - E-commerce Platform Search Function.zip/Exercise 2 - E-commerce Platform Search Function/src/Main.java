public class Main {

    public static void main(String[] args) {

        Product[] products = {

                new Product(101, "Laptop", "Electronics"),
                new Product(102, "Mobile", "Electronics"),
                new Product(103, "Shoes", "Fashion"),
                new Product(104, "Watch", "Accessories"),
                new Product(105, "Book", "Education")
        };

        System.out.println("Linear Search:");

        Product result1 =
                SearchOperations.linearSearch(products, 104);

        if (result1 != null) {
            System.out.println("Found: "
                    + result1.productName);
        } else {
            System.out.println("Product Not Found");
        }

        System.out.println("\nBinary Search:");

        Product result2 =
                SearchOperations.binarySearch(products, 104);

        if (result2 != null) {
            System.out.println("Found: "
                    + result2.productName);
        } else {
            System.out.println("Product Not Found");
        }
    }
}