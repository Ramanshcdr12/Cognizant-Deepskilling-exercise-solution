public class Main {

    public static void main(String[] args) {

        EmployeeManagement manager =
                new EmployeeManagement(10);

        manager.addEmployee(
                new Employee(101,
                        "Ramansh",
                        "Developer",
                        50000));

        manager.addEmployee(
                new Employee(102,
                        "Rahul",
                        "Tester",
                        40000));

        manager.addEmployee(
                new Employee(103,
                        "Amit",
                        "Manager",
                        70000));

        System.out.println("\nEmployee Records:");

        manager.displayEmployees();

        System.out.println("\nSearching Employee:");

        Employee employee =
                manager.searchEmployee(102);

        if (employee != null) {
            System.out.println(employee);
        }

        System.out.println("\nDeleting Employee:");

        manager.deleteEmployee(102);

        System.out.println("\nUpdated Employee Records:");

        manager.displayEmployees();
    }
}