public class Main {

    public static void main(String[] args) {

        InventoryManager manager = new InventoryManager();

        Product p1 = new Product(101, "Laptop", 10, 55000);
        Product p2 = new Product(102, "Mouse", 50, 500);

        manager.addProduct(p1);
        manager.addProduct(p2);

        System.out.println("\nInventory:");
        manager.displayProducts();

        System.out.println("\nUpdating Product...");
        manager.updateProduct(102, "Wireless Mouse", 45, 700);

        System.out.println("\nInventory After Update:");
        manager.displayProducts();

        System.out.println("\nDeleting Product...");
        manager.deleteProduct(101);

        System.out.println("\nFinal Inventory:");
        manager.displayProducts();
    }
}