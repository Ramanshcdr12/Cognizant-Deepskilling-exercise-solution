public class Main {

    public static void main(String[] args) {

        Order[] orders = {

                new Order(101, "Ram", 5000),
                new Order(102, "Shyam", 2500),
                new Order(103, "Mohan", 8000),
                new Order(104, "Ravi", 3500)
        };

        System.out.println("Before Sorting:");

        for (Order order : orders) {
            System.out.println(order);
        }

        SortOperations.quickSort(
                orders,
                0,
                orders.length - 1
        );

        System.out.println("\nAfter Quick Sort:");

        for (Order order : orders) {
            System.out.println(order);
        }
    }
}