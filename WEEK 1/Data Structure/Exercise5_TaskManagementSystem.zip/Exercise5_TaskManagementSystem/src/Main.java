public class Main {

    public static void main(String[] args) {

        TaskLinkedList taskList =
                new TaskLinkedList();

        taskList.addTask(
                new Task(101,
                        "Design Database",
                        "Pending"));

        taskList.addTask(
                new Task(102,
                        "Develop API",
                        "In Progress"));

        taskList.addTask(
                new Task(103,
                        "Testing",
                        "Pending"));

        System.out.println("All Tasks:");

        taskList.displayTasks();

        System.out.println("\nSearching Task:");

        Task task =
                taskList.searchTask(102);

        if (task != null) {

            System.out.println(
                    "Found -> " +
                            task.taskName);
        }

        System.out.println("\nDeleting Task:");

        taskList.deleteTask(102);

        System.out.println("\nUpdated Tasks:");

        taskList.displayTasks();
    }
}